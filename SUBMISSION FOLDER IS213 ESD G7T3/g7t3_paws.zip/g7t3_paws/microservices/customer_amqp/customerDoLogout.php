<?php
session_start();
session_destroy();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Logout</title>
        <meta http-equiv="refresh" content="0; url=customerLogin.php" />
    </head>
    <body>
        <?php //echo $message; ?>    
    </body>
</html>